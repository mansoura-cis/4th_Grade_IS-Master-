# Fuzzy-Logic
Fuzzy logic example implementation (air conditioner)
